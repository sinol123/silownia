alert('sad');
function change(a){
    switch (a){
        case 1:
            console.log('hhehehe');
    }
}